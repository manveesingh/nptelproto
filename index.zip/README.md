# NPTEL · SWAYAM redesign — prototype

Static HTML prototype: the existing SWAYAM course explorer with two new
features layered in — **My pathway** (AI-suggested course sequence) and
**Build Track** (guided project → make it yours → portfolio).

No build step, no dependencies beyond Google Fonts. Six pages + one index.

```
index.html          — landing page linking to all six
01-home.html         — Home / Explore courses
02-pathway.html       — My pathway
03-onboarding.html    — Build my pathway (question flow)
04-course.html        — Course page / Projects tab
05-buildtrack.html    — Build Track / Make it yours step
06-mybuilds.html      — My builds (portfolio)
```

## Put this live on GitHub Pages

1. Create a new repository on GitHub (public, so Pages is free) — e.g. `nptel-redesign-prototype`.
2. On your computer, unzip this folder and open a terminal inside it.
3. Run:
   ```bash
   git init
   git add .
   git commit -m "NPTEL redesign prototype"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
4. On GitHub, go to the repo → **Settings** → **Pages**.
5. Under **Build and deployment → Source**, choose **Deploy from a branch**.
6. Branch: `main`, folder: `/ (root)` → **Save**.
7. Wait a minute, then your site is live at:
   ```
   https://<your-username>.github.io/<repo-name>/
   ```
   That URL loads `index.html` automatically, which links to all six pages.

No `git` installed? On the repo page you can also click **Add file → Upload
files**, drag in all seven files, commit directly to `main`, then do steps
4–6 above.

## Notes

- Every page is fully self-contained (inline CSS + inline SVG icons), so
  each also opens fine directly from your file system with no server.
- Pages link to each other by relative filename (`02-pathway.html` etc.),
  so keep them all in the same folder — don't rename them individually.
- Fonts (Fredoka, Nunito Sans) load from Google Fonts over the network;
  everything else works offline.
